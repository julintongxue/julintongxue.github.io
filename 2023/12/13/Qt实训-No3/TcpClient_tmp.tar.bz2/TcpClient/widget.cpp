#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);



}

Widget::~Widget()
{
    delete ui;
}


void Widget::read_data()
{


}



void Widget::on_btn_connectServer_clicked()
{

}




void Widget::connect_sud()
{



}



void Widget::client_dis()
{


}



void Widget::on_pushButton_clicked()
{





}
