#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    mServer = new QTcpServer();
    connect(mServer,SIGNAL(newConnection()),this,SLOT(new_client()));
    mServer->listen(QHostAddress::Any,9988);

}

Widget::~Widget()
{
    delete ui;
}

void Widget::new_client()
{
    qDebug()<<"--new_client--";
    mSocket = mServer->nextPendingConnection();
    connect(mSocket,SIGNAL(readyRead()),this,SLOT(read_client_data()));
    connect(mSocket,SIGNAL(disconnected()),this,SLOT(client_dis()));
}

void Widget::read_client_data()
{
    QString msg = mSocket->readAll();
    qDebug()<<msg;
}



void Widget::client_dis()
{
    QString msg = mSocket->peerAddress().toString();
    qDebug()<<msg;
}




void Widget::on_send_bt_clicked()
{
    if(ui->sendLineEdit->text()=="")
    {
        return ;
    }
    QString msg = ui->sendLineEdit->text();
    mSocket->write(msg.toLatin1(),msg.length());
    ui->sendLineEdit->clear();

}












