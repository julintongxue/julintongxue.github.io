#include "menu.h"
#include "ui_menu.h"

menu::menu(QWidget *parent) :QMainWindow(parent),ui(new Ui::menu)
{
    ui->setupUi(this);

    //实例化对象
    SUBclient = new QMQTT::Client;
    //ubuntu服务器地址
    SUBclient->setHostName("10.73.132.109");
    SUBclient->setPort(1883);
    //绑定连接后的处理函数
    connect(SUBclient,SIGNAL(connected()),this,SLOT(Subclient_Hanlder()));
    //绑定断开连接后的处理函数
    connect(SUBclient, SIGNAL(disconnected()), this, SLOT(handleDisconnection()));
    //开始连接MQTT服务器
    SUBclient->connectToHost();
    //如果需要在连接失败时获取错误信息，可以在连接后检查状态

}

menu::~menu(){
    delete ui;
}

void menu::Subclient_Hanlder(){
    qDebug() << "connect MQTT server success,begin to subscribe." << endl;

    SubTopic = "/PTZCTL";
    SUBclient->subscribe(SubTopic);
    SUBclient->setKeepAlive(30);

    connect(SUBclient,SIGNAL(received(QMQTT::Message)),this,SLOT(DataRecvParse(QMQTT::Message)));

}

// 新增的处理连接断开的槽函数
void menu::handleDisconnection() {
    qDebug() << "Disconnected from MQTT server.";
}

void menu::DataRecvParse(QMQTT::Message recv_mes) {
    qDebug() << "receive data.....";

    QString mes = recv_mes.payload();
    qDebug() << mes.toUtf8() << endl;

    QStringList parts = mes.split(".");

    if (parts.size() >= 2) {
        QString direct = parts.at(0);
        QString status = parts.at(1);

        if (direct == "up") {
            if (status == "on") {
                ui->upArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/upArrow_On.png);"));
                qDebug() << "turn up--->";
            } else {
                ui->upArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/upArrow_Off.png);"));
            }
        } else if (direct == "down") {
            if (status == "on") {
                ui->downArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/downArrow_On.png);"));
                qDebug() << "turn down--->";
            } else {
                ui->downArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/downArrow_Off.png);"));
            }
        } else if (direct == "right") {
            if (status == "on") {
                ui->rightArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/rightArrow_On.png);"));
                qDebug() << "turn right--->";
            } else {
                ui->rightArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/rightArrow_Off.png);"));
            }
        } else if (direct == "left") {
            if (status == "on") {
                ui->leftArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/leftArrow_On.png);"));
                qDebug() << "turn left--->";
            } else {
                ui->leftArrow_lb->setStyleSheet(QStringLiteral("border-image:url(:/new/prefix1/photo/leftArrow_Off.png);"));
            }
        }
    } else {
        // 处理无效的输入
        qDebug() << "Invalid input format";
    }

}
