#ifndef MENU_H
#define MENU_H
#include "mqtt/qmqtt.h"
#include <QMainWindow>
#include <QDebug>

namespace Ui {
class menu;
}
class menu : public QMainWindow
{
    Q_OBJECT
public:
    explicit menu(QWidget *parent = 0);
    ~menu();
private slots:
    //声明处理函数
    void Subclient_Hanlder();
    void DataRecvParse(QMQTT::Message);
    //声明处理连接断开的槽函数
    void handleDisconnection();
private:
    Ui::menu *ui;
    //定义操作对象
    QMQTT::Client* SUBclient;
    //保存主题和数据
    QString SubTopic,message;

};

#endif // MENU_H
