/********************************************************************************
** Form generated from reading UI file 'menu.ui'
**
** Created by: Qt User Interface Compiler version 5.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_H
#define UI_MENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_menu
{
public:
    QWidget *centralWidget;
    QLabel *leftArrow_lb;
    QLabel *upArrow_lb;
    QLabel *rightArrow_lb;
    QLabel *downArrow_lb;

    void setupUi(QMainWindow *menu)
    {
        if (menu->objectName().isEmpty())
            menu->setObjectName(QStringLiteral("menu"));
        menu->resize(537, 377);
        menu->setStyleSheet(QStringLiteral("background-color: rgb(201, 133, 139);"));
        centralWidget = new QWidget(menu);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        leftArrow_lb = new QLabel(centralWidget);
        leftArrow_lb->setObjectName(QStringLiteral("leftArrow_lb"));
        leftArrow_lb->setGeometry(QRect(140, 134, 81, 71));
        leftArrow_lb->setStyleSheet(QStringLiteral("border-image: url(:/new/prefix1/photo/leftArrow_Off.png);"));
        upArrow_lb = new QLabel(centralWidget);
        upArrow_lb->setObjectName(QStringLiteral("upArrow_lb"));
        upArrow_lb->setGeometry(QRect(219, 60, 81, 71));
        upArrow_lb->setStyleSheet(QStringLiteral("border-image: url(:/new/prefix1/photo/upArrow_Off.png);"));
        rightArrow_lb = new QLabel(centralWidget);
        rightArrow_lb->setObjectName(QStringLiteral("rightArrow_lb"));
        rightArrow_lb->setGeometry(QRect(297, 132, 81, 71));
        rightArrow_lb->setStyleSheet(QStringLiteral("border-image: url(:/new/prefix1/photo/rightArrow_Off.png);"));
        downArrow_lb = new QLabel(centralWidget);
        downArrow_lb->setObjectName(QStringLiteral("downArrow_lb"));
        downArrow_lb->setGeometry(QRect(220, 210, 81, 71));
        downArrow_lb->setStyleSheet(QStringLiteral("border-image: url(:/new/prefix1/photo/downArrow_Off.png);"));
        menu->setCentralWidget(centralWidget);

        retranslateUi(menu);

        QMetaObject::connectSlotsByName(menu);
    } // setupUi

    void retranslateUi(QMainWindow *menu)
    {
        menu->setWindowTitle(QApplication::translate("menu", "menu", 0));
        leftArrow_lb->setText(QString());
        upArrow_lb->setText(QString());
        rightArrow_lb->setText(QString());
        downArrow_lb->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class menu: public Ui_menu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_H
