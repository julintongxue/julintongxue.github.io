/********************************************************************************
** Form generated from reading UI file 'qmenu.ui'
**
** Created by: Qt User Interface Compiler version 5.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QMENU_H
#define UI_QMENU_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_qMenu
{
public:
    QWidget *centralWidget;
    QPushButton *menu_mLamp_bt;
    QPushButton *menu_sLamp_bt;

    void setupUi(QMainWindow *qMenu)
    {
        if (qMenu->objectName().isEmpty())
            qMenu->setObjectName(QStringLiteral("qMenu"));
        qMenu->resize(1024, 600);
        qMenu->setStyleSheet(QStringLiteral("QMainWindow{border-image: url(:/new/prefix1/qImage/menuUi.jpg);}"));
        qMenu->setIconSize(QSize(100, 100));
        centralWidget = new QWidget(qMenu);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        menu_mLamp_bt = new QPushButton(centralWidget);
        menu_mLamp_bt->setObjectName(QStringLiteral("menu_mLamp_bt"));
        menu_mLamp_bt->setGeometry(QRect(290, 230, 100, 100));
        menu_mLamp_bt->setStyleSheet(QStringLiteral(""));
        QIcon icon;
        icon.addFile(QStringLiteral(":/new/prefix1/qImage/mLamp-off.png"), QSize(), QIcon::Normal, QIcon::Off);
        menu_mLamp_bt->setIcon(icon);
        menu_mLamp_bt->setIconSize(QSize(100, 100));
        menu_sLamp_bt = new QPushButton(centralWidget);
        menu_sLamp_bt->setObjectName(QStringLiteral("menu_sLamp_bt"));
        menu_sLamp_bt->setGeometry(QRect(590, 230, 100, 100));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/new/prefix1/qImage/mLamp-on.png"), QSize(), QIcon::Normal, QIcon::Off);
        menu_sLamp_bt->setIcon(icon1);
        menu_sLamp_bt->setIconSize(QSize(100, 100));
        qMenu->setCentralWidget(centralWidget);

        retranslateUi(qMenu);

        QMetaObject::connectSlotsByName(qMenu);
    } // setupUi

    void retranslateUi(QMainWindow *qMenu)
    {
        qMenu->setWindowTitle(QApplication::translate("qMenu", "qMenu", 0));
        menu_mLamp_bt->setText(QString());
        menu_sLamp_bt->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class qMenu: public Ui_qMenu {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QMENU_H
