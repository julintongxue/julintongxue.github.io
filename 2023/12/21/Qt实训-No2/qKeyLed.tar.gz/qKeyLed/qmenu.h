#ifndef QMENU_H
#define QMENU_H

#include <QMainWindow>

namespace Ui {
class qMenu;
}

class qMenu : public QMainWindow
{
    Q_OBJECT

public:
    explicit qMenu(QWidget *parent = 0);
    ~qMenu();

private slots:
    void on_menu_mLamp_bt_clicked();

    void on_menu_sLamp_bt_clicked();

private:
    Ui::qMenu *ui;
    bool mLamp_flag;
    bool sLamp_flag;
};

#endif // QMENU_H
