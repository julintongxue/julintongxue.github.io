#include "qmenu.h"
#include "ui_qmenu.h"

qMenu::qMenu(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::qMenu)
{
    ui->setupUi(this);

    //在此地添加代码
    ui->menu_mLamp_bt->setStyleSheet(QStringLiteral("background-color:rgb(180,161,161;)"));
    ui->menu_mLamp_bt->setFocusPolicy(Qt::NoFocus);
    ui->menu_sLamp_bt->setStyleSheet(QStringLiteral("background-color:rgb(180,161,161;)"));
    ui->menu_sLamp_bt->setFocusPolicy(Qt::NoFocus);
//    ui->menu_mLamp_bt->setText("主控开");

    mLamp_flag = true;
    sLamp_flag = true;
}

qMenu::~qMenu()
{
    delete ui;
}

void qMenu::on_menu_mLamp_bt_clicked()
{
    if(mLamp_flag)
    {
        mLamp_flag = false;
        ui->menu_mLamp_bt->setStyleSheet(QStringLiteral("background-color:white;"));
//        ui->menu_mLamp_bt->setText("主控开");
    }else{
        ui->menu_mLamp_bt->setStyleSheet(QStringLiteral("background-color:grey;"));
//        ui->menu_mLamp_bt->setText("主控关");
    }
}

void qMenu::on_menu_sLamp_bt_clicked()
{
    if(sLamp_flag)
    {
        sLamp_flag = false;
        ui->menu_sLamp_bt->setStyleSheet(QStringLiteral("background-color:white;"));
    }else{
        ui->menu_sLamp_bt->setStyleSheet(QStringLiteral("background-color:grey;"));
    }
}
