#include "widget.h"
#include "ui_widget.h"

widget::widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::widget)
{
    ui->setupUi(this);
    mSocket = new QTcpSocket(this);
    connect(mSocket,SIGNAL(readyRead()),this,SLOT(read_data()));
}

widget::~widget()
{
    delete ui;
}

void widget::read_data()
{
    QString msg = mSocket->readAll();
    qDebug()<<msg;
}


void widget::on_btn_connectServer_clicked()
{
    connect(mSocket,SIGNAL(connected()),this,SLOT(connect_sud()));
    connect(mSocket,SIGNAL(disconnected()),this,SLOT(client_dis()));

    mSocket->connectToHost(ui->ipEdit->text(),ui->portEdit->text().toInt());
}

void widget::connect_sud()
{
    ui->btn_connectServer->setEnabled(false);
}

void widget::client_dis()
{
    ui->btn_connectServer->setEnabled(true);
}

void widget::on_pushButton_clicked()
{
    if(ui->sendLineEdit->text()=="")
    {
        return ;
    }
    QString msg = ui->sendLineEdit->text();
    mSocket->write(msg.toLatin1(),msg.length());
    ui->sendLineEdit->clear();
}
