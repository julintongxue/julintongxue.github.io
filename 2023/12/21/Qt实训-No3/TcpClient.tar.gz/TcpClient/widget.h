#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QTcpSocket>

namespace Ui {
class widget;
}

class widget : public QWidget
{
    Q_OBJECT

public:
    explicit widget(QWidget *parent = 0);
    ~widget();

private slots:
    void read_data();
    void connect_sud();
    void client_dis();
    void on_btn_connectServer_clicked();
    void on_pushButton_clicked();

private:
    Ui::widget *ui;
    QTcpSocket *mSocket;
};

#endif // WIDGET_H
