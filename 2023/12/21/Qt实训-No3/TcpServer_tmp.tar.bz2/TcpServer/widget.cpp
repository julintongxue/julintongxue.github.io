#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);




}

Widget::~Widget()
{
    delete ui;
}

void Widget::new_client()
{


}

void Widget::read_client_data()
{



}





void Widget::client_dis()
{





}




void Widget::on_send_bt_clicked()
{




}













